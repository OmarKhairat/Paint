# Installation
> `npm install --save @types/estree`

# Summary
This package contains type definitions for ESTree AST specification (https://github.com/estree/estree).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/estree.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 19:03:41 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [RReverser](https://github.com/RReverser).
