declare module 'console' {
    export = console;
}
