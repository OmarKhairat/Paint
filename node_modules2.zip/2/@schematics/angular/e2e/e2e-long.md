The e2e tests are created in a separate app in the `projects` folder of the workspace,
next to the project being tested.
