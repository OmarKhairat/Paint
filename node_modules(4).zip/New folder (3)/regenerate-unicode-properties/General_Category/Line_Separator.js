const set = require('regenerate')(0x2028);

module.exports = set;
