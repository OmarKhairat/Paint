const set = require('regenerate')();
set.addRange(0x11AC0, 0x11AF8);
module.exports = set;
