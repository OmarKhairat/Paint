const set = require('regenerate')(0x1039F);
set.addRange(0x10380, 0x1039D);
module.exports = set;
