const set = require('regenerate')();
set.addRange(0x11A00, 0x11A47);
module.exports = set;
