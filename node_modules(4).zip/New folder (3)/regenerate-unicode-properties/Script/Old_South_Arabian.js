const set = require('regenerate')();
set.addRange(0x10A60, 0x10A7F);
module.exports = set;
