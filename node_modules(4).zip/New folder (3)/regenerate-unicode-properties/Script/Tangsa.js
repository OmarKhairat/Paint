const set = require('regenerate')();
set.addRange(0x16A70, 0x16ABE).addRange(0x16AC0, 0x16AC9);
module.exports = set;
