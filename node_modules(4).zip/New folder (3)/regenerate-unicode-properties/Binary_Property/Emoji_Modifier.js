const set = require('regenerate')();
set.addRange(0x1F3FB, 0x1F3FF);
module.exports = set;
