const set = require('regenerate')(0x640, 0x10AF2);
set.addRange(0x10F70, 0x10F89);
module.exports = set;
