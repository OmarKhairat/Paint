declare module 'hdr-histogram-percentiles-obj';
